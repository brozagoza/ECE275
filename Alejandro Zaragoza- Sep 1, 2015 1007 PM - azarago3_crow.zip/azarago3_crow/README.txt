Author: Alejandro Zaragoza
NetID: azarago3
Date: 3 September 2015
Assignment Number: 0

This program that echoes a word differently, depending on the word that is passed in. Usage:
  crow [word]
  
The inputted word should be echoed back to the terminal. If the word is Snow, or Corn, 
it should be echoed as

  "Corn," the bird said. "Corn, corn."

with a newline at the end (likewise in the case of Snow).
