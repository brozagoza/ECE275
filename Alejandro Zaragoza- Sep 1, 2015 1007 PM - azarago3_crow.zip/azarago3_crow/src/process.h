#ifndef PROCESS_H
#define PROCESS_H

#include <stdlib.h>
#include <stdio.h>

/*
 Author: Jonathan Sprinkle
 Net ID: sprinkjm
 Date:   25 August 2015
 Assignment 0
 
 Signature definition for the process function.
 
 */


void process( char *word );

#endif // PROCESS_H