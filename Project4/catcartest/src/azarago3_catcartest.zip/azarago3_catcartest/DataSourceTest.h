#include <iostream>
using namespace std;

class DataSourceTest
{
public:
    DataSourceTest();
    // Tests everything
    bool test();
    
private:
    
};