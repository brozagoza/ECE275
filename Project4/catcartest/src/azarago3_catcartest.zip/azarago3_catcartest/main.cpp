#include "DataSource.h"
#include "DataSourceTest.h"
#include <iostream>
using namespace std;

int main (void)
{
    DataSourceTest temp;
    temp.test();
    
}