Author: Alejandro Zaragoza
NetID: azarago3
Date: 10 November 2015
Assignment: #4

This is the program that does the car stuff. Prepare youreself.